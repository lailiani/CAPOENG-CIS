<?php
// customer_add.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config/db.php'; // koneksi $pdo
include '../includes/header.php';

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_code = $_POST['customer_code'];
    $name          = $_POST['name'];
    $email         = $_POST['email'];
    $phone         = $_POST['phone'];
    $service       = $_POST['service'];
    $status        = $_POST['status'];
    $monthly_fee   = $_POST['monthly_fee'];

    try {
        $stmt = $pdo->prepare("INSERT INTO customers 
            (customer_code, name, email, phone, service, status, monthly_fee, join_date) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $customer_code, $name, $email, $phone, $service, $status, $monthly_fee
        ]);

        header("Location: customers.php");
        exit;
    } catch (PDOException $e) {
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<div class="container mt-4">
  <h2>Tambah Pelanggan</h2>
  <form method="POST">
    <div class="mb-3">
      <label class="form-label">Kode Pelanggan</label>
      <input type="text" name="customer_code" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Nama</label>
      <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control">
    </div>
    <div class="mb-3">
      <label class="form-label">Telepon</label>
      <input type="text" name="phone" class="form-control">
    </div>
    <div class="mb-3">
    <label>Service</label>
    <select name="service" class="form-control" required>
        <option value="Internet 100 Mbps">Internet 100 Mbps</option>
        <option value="Internet 50 Mbps">Internet 50 Mbps</option>
        <option value="Domain">Domain</option>
        <option value="Hosting">Hosting</option>
    </select>
</div>
    <div class="mb-3">
      <label class="form-label">Status</label>
      <select name="status" class="form-select" required>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
        <option value="suspended">Suspended</option>
      </select>
    </div>
	<div class="mb-3">
    	<label>Tagihan/Bulan</label>
    	<input type="number" name="monthly_fee" class="form-control" readonly>
	</div>
    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="customers.php" class="btn btn-secondary">Batal</a>
  </form>
<script>
function setMonthlyFee() {
    var service = document.querySelector('[name="service"]').value;
    var fee = 0;
    if (service === 'Internet 100 Mbps') fee = 300000;
    else if (service === 'Internet 50 Mbps') fee = 175000;
    else if (service === 'Domain') fee = 10000;
    else if (service === 'Hosting') fee = 50000;
    document.querySelector('[name="monthly_fee"]').value = fee;
}
document.querySelector('[name="service"]').addEventListener('change', setMonthlyFee);
// Panggil saat halaman pertama kali dibuka
setMonthlyFee();
</script>
</div>

<?php include '../includes/footer.php'; ?>
