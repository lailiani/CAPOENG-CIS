<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config/db.php';
include '../includes/header.php';

// =========================
// HANDLE POST / GET ACTION
// =========================

// Tambah pembayaran
if (isset($_POST['add_payment'])) {
    $customer_id = $_POST['customer_id'] ?? '';
    $amount = $_POST['amount'] ?? 0;
    $paid_at = $_POST['paid_at'] ?? date('Y-m-d H:i:s');
    $method = $_POST['method'] ?? 'cash';
    $note = $_POST['note'] ?? '';

    $sql = "INSERT INTO payments (customer_id, amount, paid_at, method, note)
            VALUES (:customer_id, :amount, :paid_at, :method, :note)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':customer_id' => $customer_id,
        ':amount' => $amount,
        ':paid_at' => $paid_at,
        ':method' => $method,
        ':note' => $note
    ]);
    header("Location: payments.php");
    exit;
}

// Edit pembayaran
if (isset($_POST['edit_payment'])) {
    $id = $_POST['id'] ?? 0;
    $customer_id = $_POST['customer_id'] ?? '';
    $amount = $_POST['amount'] ?? 0;
    $paid_at = $_POST['paid_at'] ?? date('Y-m-d H:i:s');
    $method = $_POST['method'] ?? 'cash';
    $note = $_POST['note'] ?? '';

    $sql = "UPDATE payments 
            SET customer_id=:customer_id, amount=:amount, paid_at=:paid_at, method=:method, note=:note
            WHERE id=:id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => $id,
        ':customer_id' => $customer_id,
        ':amount' => $amount,
        ':paid_at' => $paid_at,
        ':method' => $method,
        ':note' => $note
    ]);
    header("Location: payments.php");
    exit;
}

// Hapus pembayaran
if (isset($_GET['delete'])) {
    $id = $_GET['delete'] ?? 0;
    $pdo->prepare("DELETE FROM payments WHERE id=?")->execute([$id]);
    header("Location: payments.php");
    exit;
}

// =========================
// FETCH DATA
// =========================
$search = $_GET['search'] ?? '';

// Ambil data pembayaran dengan filter search
$sql = "SELECT p.*, c.name AS customer_name, c.customer_code, c.monthly_fee
        FROM payments p
        LEFT JOIN customers c ON p.customer_id = c.id
        WHERE c.name LIKE :search OR c.customer_code LIKE :search OR DATE(p.paid_at) LIKE :search
        ORDER BY p.paid_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([':search' => "%$search%"]);
$payments = $stmt->fetchAll();

// Ambil data customer untuk dropdown
$customers = $pdo->query("SELECT id, name, service, monthly_fee FROM customers ORDER BY name")->fetchAll();
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="d-flex justify-content-between align-items-center mb-3">
    <h2>Data Pembayaran</h2>
    <div class="d-flex">
        <form method="get" class="me-2">
            <input type="text" name="search" class="form-control" placeholder="Cari..." value="<?= htmlspecialchars($search) ?>">
        </form>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPaymentModal">+ Tambah Pembayaran</button>
    </div>
</div>

<table class="table table-bordered table-striped">
<thead>
<tr>
    <th>Kode Pelanggan</th>
    <th>Customer</th>
    <th>Jumlah</th>
    <th>Tanggal Bayar</th>
    <th>Metode</th>
    <th>Catatan</th>
    <th>Aksi</th>
</tr>
</thead>
<tbody>
<?php foreach ($payments as $p): ?>
<tr>
    <td><?= htmlspecialchars($p['customer_code'] ?? '') ?></td>
    <td><?= htmlspecialchars($p['customer_name'] ?? '') ?></td>
    <td>Rp <?= number_format($p['amount'] ?? 0,0,',','.') ?></td>
    <td><?= $p['paid_at'] ?? '' ?></td>
    <td><?= htmlspecialchars($p['method'] ?? '') ?></td>
    <td><?= htmlspecialchars($p['note'] ?? '') ?></td>
    <td>
        <button type="button" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editPaymentModal<?= $p['id'] ?>">Edit</button>
        <a href="payments.php?delete=<?= $p['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus pembayaran ini?')">Hapus</a>
    </td>
</tr>

<!-- Modal Edit -->
<div class="modal fade" id="editPaymentModal<?= $p['id'] ?>" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post">
        <div class="modal-header">
          <h5 class="modal-title">Edit Pembayaran</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" value="<?= $p['id'] ?>">
          <div class="mb-3">
            <label>Customer</label>
            <select name="customer_id" class="form-control" required onchange="updateAmount(this, <?= $p['id'] ?>)">
                <?php foreach($customers as $c): ?>
                    <option value="<?= $c['id'] ?>" data-fee="<?= $c['monthly_fee'] ?>" <?= ($c['id']==($p['customer_id'] ?? 0)?'selected':'') ?>>
                        <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['service']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label>Jumlah</label>
            <input type="number" step="0.01" name="amount" id="edit_amount_<?= $p['id'] ?>" value="<?= $p['amount'] ?? 0 ?>" class="form-control" required readonly>
          </div>
          <div class="mb-3">
            <label>Tanggal Bayar</label>
            <input type="datetime-local" name="paid_at" value="<?= isset($p['paid_at']) ? date('Y-m-d\TH:i', strtotime($p['paid_at'])) : '' ?>" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Metode</label>
            <input type="text" name="method" value="<?= htmlspecialchars($p['method'] ?? '') ?>" class="form-control">
          </div>
          <div class="mb-3">
            <label>Catatan</label>
            <input type="text" name="note" value="<?= htmlspecialchars($p['note'] ?? '') ?>" class="form-control">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="edit_payment" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php endforeach; ?>
</tbody>
</table>

<!-- Modal Tambah -->
<div class="modal fade" id="addPaymentModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="post">
        <div class="modal-header">
          <h5 class="modal-title">Tambah Pembayaran</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label>Customer</label>
            <select name="customer_id" class="form-control" required onchange="updateAmount(this, 'add')">
                <option value="">-- Pilih Customer --</option>
                <?php foreach($customers as $c): ?>
                    <option value="<?= $c['id'] ?>" data-fee="<?= $c['monthly_fee'] ?>">
                        <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['service']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label>Jumlah</label>
            <input type="number" step="0.01" name="amount" id="add_amount" class="form-control" required readonly>
          </div>
          <div class="mb-3">
            <label>Tanggal Bayar</label>
            <input type="datetime-local" name="paid_at" class="form-control" value="<?= date('Y-m-d\TH:i') ?>" required>
          </div>
          <div class="mb-3">
            <label>Metode</label>
            <input type="text" name="method" class="form-control" value="cash">
          </div>
          <div class="mb-3">
            <label>Catatan</label>
            <input type="text" name="note" class="form-control">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="add_payment" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updateAmount(select, id) {
    const fee = select.options[select.selectedIndex].dataset.fee || 0;
    const inputId = id === 'add' ? 'add_amount' : 'edit_amount_' + id;
    document.getElementById(inputId).value = fee;
}
</script>

<?php include '../includes/footer.php'; ?>
