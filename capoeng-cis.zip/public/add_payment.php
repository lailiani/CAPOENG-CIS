<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config/db.php';
include '../includes/header.php';

// Ambil daftar customer
$stmt = $pdo->query("SELECT id, name, service FROM customers ORDER BY name ASC");
$customers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_id = $_POST['customer_id'];
    $method = $_POST['method'];
    $payment_date = date('Y-m-d');

    // Hitung jumlah berdasarkan service
    $stmt = $pdo->prepare("SELECT service FROM customers WHERE id=?");
    $stmt->execute([$customer_id]);
    $service = $stmt->fetchColumn();

    $amount = 0;
    if ($service === 'Internet 100 Mbps') $amount = 300000;
    else if ($service === 'Internet 50 Mbps') $amount = 175000;
    else if ($service === 'Domain') $amount = 10000;
    else if ($service === 'Hosting') $amount = 50000;

    // Simpan ke payments
    $stmt = $pdo->prepare("INSERT INTO payments (customer_id, amount, method, payment_date) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$customer_id, $amount, $method, $payment_date])) {
        $message = "✅ Pembayaran berhasil ditambahkan.";
    } else {
        $message = "❌ Gagal menambahkan pembayaran.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Pembayaran</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        form { max-width: 400px; }
        label { display: block; margin-top: 10px; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 15px; padding: 8px 15px; }
        .msg { margin: 10px 0; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Tambah Pembayaran</h2>
    <?php if ($message): ?>
        <p class="msg"><?= $message ?></p>
    <?php endif; ?>

    <form method="post">
        <label for="customer_id">Customer</label>
        <select name="customer_id" required>
            <option value="">-- Pilih Customer --</option>
            <?php foreach ($customers as $c): ?>
                <option value="<?= $c['id'] ?>">
                    <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['service']) ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <label for="method">Metode Pembayaran</label>
        <select name="method" required>
            <option value="">-- Pilih Metode --</option>
            <option value="Cash">Cash</option>
            <option value="Transfer">Transfer</option>
            <option value="E-Wallet">E-Wallet</option>
        </select>

        <button type="submit">Simpan</button>
    </form>

    <br>
    <a href="payments.php">⬅ Kembali ke Daftar Pembayaran</a>
</body>
</html>
