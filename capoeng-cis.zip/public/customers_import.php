<?php include 'header.php'; ?>
<div class="container mt-4">
  <h3>Import Pelanggan dari Excel</h3>
  <form action="customers_import_process.php" method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label for="file" class="form-label">Pilih File Excel (.xlsx / .csv)</label>
      <input type="file" name="file" id="file" class="form-control" accept=".xls,.xlsx,.csv" required>
    </div>
    <button type="submit" class="btn btn-primary">Upload</button>
  </form>
</div>
<?php include 'footer.php'; ?>
