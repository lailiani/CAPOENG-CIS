<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

// customers.php
require '../config/db.php';
include '../includes/header.php';

//delete pelanggan
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $delete = $pdo->prepare("DELETE FROM customers WHERE id = ?");
    $delete->execute([$id]);
    header("Location: customers.php");
    exit;
}

// Ambil keyword search
$search = $_GET['search'] ?? '';

// Ambil data pelanggan dengan filter search
$sql = "SELECT * FROM customers 
        WHERE customer_code LIKE :search 
           OR name LIKE :search 
           OR email LIKE :search
           OR phone LIKE :search
           OR service LIKE :search
        ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([':search' => "%$search%"]);
$result = $stmt->fetchAll();
?>
<div class="container mt-4">
  <h2>Data Pelanggan</h2>

  <div class="d-flex mb-3">
    <form method="get" class="me-2">
        <input type="text" name="search" class="form-control" placeholder="Cari pelanggan..." value="<?= htmlspecialchars($search) ?>">
    </form>
    <a href="customer_add.php" class="btn btn-primary me-2">+ Tambah Pelanggan</a>
    <a href="customers_import.php" class="btn btn-success">Import Excel</a>
  </div>

  <table class="table table-bordered table-striped">
    <thead class="table-dark">
      <tr>
        <th>Kode</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Telepon</th>
        <th>Layanan</th>
        <th>Status</th>
        <th>Tagihan</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($result as $row): ?>
        <tr>
          <td><?= htmlspecialchars($row['customer_code']) ?></td>
          <td><?= htmlspecialchars($row['name']) ?></td>
          <td><?= htmlspecialchars($row['email']) ?></td>
          <td><?= htmlspecialchars($row['phone']) ?></td>
          <td><?= htmlspecialchars($row['service']) ?></td>
          <td>
            <span class="badge bg-<?= $row['status']=='active'?'success':($row['status']=='inactive'?'secondary':'danger') ?>">
              <?= $row['status'] ?>
            </span>
          </td>
          <td>Rp <?= number_format($row['monthly_fee'],0,',','.') ?></td>
          <td>
            <a href="customer_edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
            <a href="customers.php?delete=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include '../includes/footer.php'; ?>
