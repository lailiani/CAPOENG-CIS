<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require __DIR__ . '/../vendor/autoload.php'; // autoload PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\IOFactory;

// Koneksi PDO
$host = "localhost";
$dbname = "capoeng_cis";
$username = "leli";
$password = "leli";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}

$importResult = "";

if (isset($_POST['import'])) {
    $fileName = $_FILES['file']['tmp_name'];

    if ($_FILES['file']['size'] > 0) {
        $spreadsheet = IOFactory::load($fileName);
        $sheet = $spreadsheet->getActiveSheet();
        $rows = $sheet->toArray();

        $success = 0;
        $failed = 0;

        for ($i = 1; $i < count($rows); $i++) {
            $row = $rows[$i];

            // Gunakan null coalescing operator biar aman dari warning
            $name    = trim($row[0] ?? '');
            $email   = trim($row[1] ?? '');
            $phone   = trim($row[2] ?? '');
            $address = trim($row[3] ?? '');
            $service = trim($row[4] ?? '');
            $monthly_fee = !empty($row[5]) ? $row[5] : 0.00;

            // Generate kode unik
            $stmtCount = $pdo->query("SELECT COUNT(*) FROM customers");
            $count = $stmtCount->fetchColumn() + 1;
            $customer_code = "CUST-" . str_pad($count, 4, "0", STR_PAD_LEFT);

            $sql = "INSERT INTO customers 
                    (customer_code, name, email, phone, address, join_date, service, status, monthly_fee) 
                    VALUES (:customer_code, :name, :email, :phone, :address, :join_date, :service, :status, :monthly_fee)";
            
            $stmt = $pdo->prepare($sql);
            $joinDate = date("Y-m-d H:i:s");

            try {
                $stmt->execute([
                    ':customer_code' => $customer_code,
                    ':name'          => $name,
                    ':email'         => $email,
                    ':phone'         => $phone,
                    ':address'       => $address,
                    ':join_date'     => $joinDate,
                    ':service'       => $service,
                    ':status'        => 'active',
                    ':monthly_fee'   => $monthly_fee
                ]);
                $success++;
            } catch (Exception $e) {
                $failed++;
            }
        }

        $importResult = "Import selesai. Berhasil: $success | Gagal: $failed";
    }
}
?>

<!-- Form Upload -->
<form method="post" enctype="multipart/form-data">
    <input type="file" name="file" accept=".xls,.xlsx" required>
    <button type="submit" name="import">Import</button>
</form>

<?php if (!empty($importResult)): ?>
    <p><?= $importResult ?></p>
    <a href="dashboard.php">
        <button type="button">Kembali ke Dashboard</button>
    </a>
<?php endif; ?>
