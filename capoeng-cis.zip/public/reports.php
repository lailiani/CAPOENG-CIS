<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require '../config/db.php';
include '../includes/header.php';

// Tentukan tahun, default tahun berjalan
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Ambil data pendapatan per bulan
$sql = "SELECT 
            MONTH(paid_at) as month, 
            SUM(amount) as total 
        FROM payments 
        WHERE YEAR(paid_at) = ? 
        GROUP BY MONTH(paid_at)";
$stmt = $pdo->prepare($sql);
$stmt->execute([$year]);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

$monthlyData = array_fill(1, 12, 0); // isi 12 bulan default 0
foreach ($result as $row) {
    $monthlyData[(int)$row['month']] = (float)$row['total'];
}

//$stmt->close();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3>Laporan Pendapatan Tahun <?= htmlspecialchars($year) ?></h3>
    <form method="GET" class="d-flex">
        <select name="year" class="form-select me-2">
            <?php for ($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                <option value="<?= $y ?>" <?= ($y == $year ? 'selected' : '') ?>><?= $y ?></option>
            <?php endfor; ?>
        </select>
        <button type="submit" class="btn btn-primary">Tampilkan</button>
    </form>
</div>

<div class="row">
    <div class="col-md-6">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Bulan</th>
                    <th>Total Pendapatan (Rp)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $bulanNama = [1=>"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"];
                $grandTotal = 0;
                foreach ($monthlyData as $bulan => $total): 
                    $grandTotal += $total;
                ?>
                    <tr>
                        <td><?= $bulanNama[$bulan] ?></td>
                        <td><?= number_format($total,0,',','.') ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr class="fw-bold table-secondary">
                    <td>Total</td>
                    <td><?= number_format($grandTotal,0,',','.') ?></td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="col-md-6">
        <canvas id="reportChart"></canvas>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('reportChart');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_values($bulanNama)) ?>,
            datasets: [{
                label: 'Pendapatan (Rp)',
                data: <?= json_encode(array_values($monthlyData)) ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
</script>

<?php include '../includes/footer.php'; ?>
