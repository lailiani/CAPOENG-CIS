<?php
require_once "../config/db.php";

$username = "admin";
$password = "admin123";
$nama     = "Administrator";

$hashed_password = password_hash($password, PASSWORD_DEFAULT);

try {
    // Insert baru atau update kalau sudah ada username yang sama
    $stmt = $pdo->prepare("
        INSERT INTO users (username, password_hash, full_name)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            password_hash = VALUES(password_hash), 
            full_name = VALUES(full_name)
    ");
    $stmt->execute([$username, $hashed_password, $nama]);

    echo "✅ Admin berhasil dibuat/diupdate!<br>";
    echo "Username: $username<br>";
    echo "Password: $password<br>";
} catch (PDOException $e) {
    echo "❌ Gagal membuat admin: " . $e->getMessage();
}
