<?php
session_start();
require_once "../config/db.php";
require_once "../includes/auth.php";

// hitung total pelanggan & pendapatan bulan ini
$totalCustomers = $pdo->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$totalRevenue = $pdo->query("SELECT SUM(amount) FROM payments WHERE MONTH(paid_at)=MONTH(CURRENT_DATE()) AND YEAR(paid_at)=YEAR(CURRENT_DATE())")->fetchColumn();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Capoeng CIS</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="d-flex">
    <?php include "../includes/sidebar.php"; ?>
    <div class="p-4 flex-grow-1">
        <h2>Dashboard</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="card p-3 shadow-sm">
                    <h4>Total Pelanggan</h4>
                    <p class="fs-3"><?= $totalCustomers ?></p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-3 shadow-sm">
                    <h4>Pendapatan Bulan Ini</h4>
                    <p class="fs-3">Rp <?= number_format($totalRevenue,0,',','.') ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
