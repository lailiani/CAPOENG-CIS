<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
//session_start();
require_once "../config/db.php";
require_once "../includes/auth.php";

// cek kalau ada id di URL
if (!isset($_GET['id'])) {
    header("Location: customers.php");
    exit;
}

$id = $_GET['id'];

// ambil data pelanggan
$stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->execute([$id]);
$customer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$customer) {
    echo "❌ Data tidak ditemukan!";
    exit;
}

// update data kalau form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
	$service = $_POST['service'];
	$monthly_fee = $_POST['monthly_fee'];
	$status  = $_POST['status']; // Tambahkan status

    $update = $pdo->prepare("UPDATE customers SET name=?, email=?, phone=?, service=?, monthly_fee=?, status=? WHERE id=?");
    $update->execute([$name, $email, $phone, $service, $monthly_fee, $status, $id]);

    header("Location: customers.php");
    exit;
}
?>

<?php include "../includes/header.php"; ?>


<div class="container mt-4">
    <h2>Edit Data Pelanggan</h2>

    <form method="post">
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($customer['name']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($customer['email']) ?>">
        </div>
        <div class="mb-3">
            <label>No HP</label>
            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($customer['phone']) ?>">
        </div>
		<div class="mb-3">
    <label>Service</label>
    <select name="service" class="form-control" required>
        <option value="Internet 100 Mbps" <?= $customer['service']=='Internet 100 Mbps'?'selected':'' ?>>Internet 100 Mbps</option>
        <option value="Internet 50 Mbps" <?= $customer['service']=='Internet 50 Mbps'?'selected':'' ?>>Internet 50 Mbps</option>
        <option value="Domain" <?= $customer['service']=='Domain'?'selected':'' ?>>Domain</option>
        <option value="Hosting" <?= $customer['service']=='Hosting'?'selected':'' ?>>Hosting</option>
    </select>
</div>
<div class="mb-3">
    <label>Tagihan/Bulan</label>
    <input type="number" name="monthly_fee" class="form-control" readonly>
</div>
		<div class="mb-3">
  		  <label>Status</label>
   		 <select name="status" class="form-control" required>
       		 <option value="active"   <?= $customer['status'] == 'active'   ? 'selected' : '' ?>>Active</option>
       		 <option value="inactive" <?= $customer['status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
       		 <option value="suspended"  <?= $customer['status'] == 'suspended'  ? 'selected' : '' ?>>Suspended</option>
    </select>
</div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="customers.php" class="btn btn-secondary">Batal</a>
    </form>
<script>
function setMonthlyFee() {
    var service = document.querySelector('[name="service"]').value;
    var fee = 0;
    if (service === 'Internet 100 Mbps') fee = 300000;
    else if (service === 'Internet 50 Mbps') fee = 175000;
    else if (service === 'Domain') fee = 10000;
    else if (service === 'Hosting') fee = 50000;
    document.querySelector('[name="monthly_fee"]').value = fee;
}
document.querySelector('[name="service"]').addEventListener('change', setMonthlyFee);
// Panggil saat halaman pertama kali dibuka
setMonthlyFee();
</script>
</div>

<?php include "../includes/footer.php"; ?>
