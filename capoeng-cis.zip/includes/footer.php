<?php
// footer.php
?>
    </div> <!-- end content -->

    <!-- Sticky Footer -->
    <div class="footer">
      <img src="/assets/img/logo.png" alt="Logo Perusahaan">
      <span>© 2025 PT. CAPOENG DIGITAL NUSANTARA</span>
    </div>

    <style>
      .footer {
        position: sticky;
        bottom: 0;
        width: 100%;
        background-color: #d0e1f9; /* biru bootstrap */
        color: #000;
        padding: 6px 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.85rem;
        box-shadow: 0 -2px 5px rgba(0,0,0,0.1);
      }
      .footer img {
        height: 22px;
        margin-right: 8px;
      }
    </style>
  </div> <!-- end main -->
</body>
</html>
