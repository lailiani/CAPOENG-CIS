<div class="d-flex flex-column p-3 bg-dark text-white vh-100" style="width:250px;">
  <h4>Capoeng CIS</h4>
  <ul class="nav nav-pills flex-column">
    <li class="nav-item"><a href="dashboard.php" class="nav-link text-white">Dashboard</a></li>
    <li class="nav-item"><a href="customers.php" class="nav-link text-white">Pelanggan</a></li>
    <li class="nav-item"><a href="payments.php" class="nav-link text-white">Pembayaran</a></li>
    <li class="nav-item"><a href="reports.php" class="nav-link text-white">Laporan</a></li>
    <li class="nav-item"><a href="logout.php" class="nav-link text-danger">Logout</a></li>
  </ul>
</div>
