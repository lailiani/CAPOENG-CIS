<?php
// header.php
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sistem Informasi Pelanggan</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      min-height: 100vh;
      display: flex;
      flex-direction: row;
      margin: 0;
    }
    .sidebar {
      width: 220px;
      background-color: #343a40;
      color: #fff;
      flex-shrink: 0;
      display: flex;
      flex-direction: column;
      position: sticky;
      top: 0;
      height: 100vh;
    }
    .sidebar a {
      color: #adb5bd;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }
    .sidebar a:hover {
      background-color: #495057;
      color: #fff;
    }
    .main {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }
    .header {
      position: sticky;
      top: 0;
      z-index: 1030;
      background-color: #d0e1f9; /* biru bootstrap */
        color: #000;
      padding: 10px 20px;
      display: flex;
      align-items: center;
    }
    .header img {
      height: 40px;
      margin-right: 12px;
    }
    .content {
      flex-grow: 1;
      padding: 20px;
      background: #f8f9fa;
    }
  </style>
</head>
<body>
  <div class="sidebar">
    <h4 class="p-3 text-center">Admin Panel</h4>
    <a href="customers.php"><i class="bi bi-people-fill"></i> Pelanggan</a>
	<a href="payments.php"><i class="bi bi-credit-card-fill"></i> Pembayaran</a>
	<a href="reports.php"><i class="bi bi-bar-chart-fill"></i> Laporan</a>
	<a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
  </div>
  
  <div class="main">
    <!-- Sticky Header -->
    <div class="header">
      <img src="/assets/img/logo.png" alt="Logo Perusahaan">
      <h5 class="mb-0">PT. CAPOENG DIGITAL NUSANTARA</h5>
    </div>

    <div class="content">
