<?php
$host = "localhost";
$db   = "capoeng_cis";
$user = "leli";   // ganti sesuai user MariaDB
$pass = "leli";       // ganti password root/db user

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}
